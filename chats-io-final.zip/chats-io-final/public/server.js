const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static files (your frontend)
app.use(express.static(path.join(__dirname, 'public')));

// Track users: username -> socket.id
const users = {};

io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  // User registers with their username
  socket.on('register', (username) => {
    users[username] = socket.id;
    console.log(`Registered: ${username} -> ${socket.id}`);

    // Broadcast total connected clients
    io.emit('clients-total', Object.keys(users).length);
  });

  // Public message
  socket.on('message', (data) => {
    io.emit('chat-message', data);
  });

  // Private message
  socket.on('private_message', ({ to, from, message, dateTime }) => {
    const targetSocketId = users[to];
    if (targetSocketId) {
      io.to(targetSocketId).emit('private_message', {
        from,
        message,
        dateTime
      });
    }
  });

  // Typing feedback
  socket.on('feedback', (data) => {
    socket.broadcast.emit('feedback', data);
  });

  socket.on('disconnect', () => {
    // Remove disconnected user
    for (const [username, id] of Object.entries(users)) {
      if (id === socket.id) {
        delete users[username];
        break;
      }
    }
    io.emit('clients-total', Object.keys(users).length);
    console.log('Client disconnected:', socket.id);
  });
});

server.listen(3000, () => {
  console.log('Server listening on http://localhost:3000');
});
