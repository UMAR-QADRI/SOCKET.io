import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
import {
  getAuth,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDPR1-QoukeBEBM6Bw0_4F-ZP_ZOi8Q2Sg",
  authDomain: "collabsphere-2ff89.firebaseapp.com",
  projectId: "collabsphere-2ff89",
  storageBucket: "collabsphere-2ff89.appspot.com",
  messagingSenderId: "1052302666732",
  appId: "1:1052302666732:web:54e99b23963a3cad45aec9",
  measurementId: "G-SMWFGRDYDY"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

document.addEventListener("DOMContentLoaded", () => {
  const sendPrivateBtn = document.getElementById("send-private-btn");

  sendPrivateBtn.addEventListener("click", async () => {
    const receiverId = document.getElementById("private-receiver").value.trim();
    const messageText = document.getElementById("private-message").value.trim();

    if (!receiverId || !messageText) {
      alert("Receiver UID and message are required.");
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      alert("You must be logged in to send a private message.");
      return;
    }

    try {
      await addDoc(collection(db, "privateMessages"), {
        senderId: user.uid,
        receiverId: receiverId,
        text: messageText,
        timestamp: serverTimestamp()
      });
      alert("Private message sent!");
      document.getElementById("private-message").value = "";
    } catch (error) {
      console.error("Error sending private message:", error);
      alert("Failed to send private message.");
    }
  });
});
