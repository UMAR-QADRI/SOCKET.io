import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDPR1-QoukeBEBM6Bw0_4F-ZP_ZOi8Q2Sg",
    authDomain: "collabsphere-2ff89.firebaseapp.com",
    projectId: "collabsphere-2ff89",
    storageBucket: "collabsphere-2ff89.appspot.com",
    messagingSenderId: "1052302666732",
    appId: "1:1052302666732:web:54e99b23963a3cad45aec9",
    measurementId: "G-SMWFGRDYDY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Handle signup form submission
document.getElementById('signupForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
   
    try {
        // Create a new user with email and password
        const userCredential = await createUserWithEmailAndPassword(auth, email, password,Number);
        alert(`Welcome, ${username}! Your account has been created.`);
        
        // Optionally, save the username in a database (if needed).
        // Redirect to the next page (index.html)
        window.location.href = "login.html";
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
});
