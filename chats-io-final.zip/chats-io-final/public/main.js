const userMap = {}; // username => socket.id

const socket = io();

const clientsTotal = document.getElementById('client-total');
const messageContainer = document.getElementById('message-container');
const nameInput = document.getElementById('name-input');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const messageTone = document.getElementById('tone');

// Register user on input change
nameInput.addEventListener('blur', () => {
  if (nameInput.value) {
    localStorage.setItem('username', nameInput.value);
    socket.emit('register', nameInput.value);
  }
});

// Auto load saved name
window.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('username');
  if (saved) {
    nameInput.value = saved;
    socket.emit('register', saved);
  }
});

// Handle form submission
messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  sendMessage();
});

function sendMessage() {
  const input = messageInput.value.trim();
  if (!input) return;

  const name = nameInput.value;
  const dateTime = new Date();

  // Check for private message syntax: /w username message
  if (input.startsWith('/w ')) {
    const parts = input.split(' ');
    const to = parts[1];
    const message = parts.slice(2).join(' ');
    socket.emit('private_message', { to, from: name, message, dateTime });
  } else {
    socket.emit('message', { name, message: input, dateTime });
  }

  messageInput.value = '';
}

// Listen for public chat messages
socket.on('chat-message', (data) => {
  messageTone.play();
  addMessageToUI(data.name === nameInput.value, data);
});

// Listen for private messages
socket.on('private_message', (data) => {
  messageTone.play();
  addMessageToUI(false, { ...data, message: `(Private) ${data.message}` });
});

// Typing feedback
messageInput.addEventListener('focus', () => {
  socket.emit('feedback', { feedback: `✍️ ${nameInput.value} is typing` });
});
messageInput.addEventListener('keypress', () => {
  socket.emit('feedback', { feedback: `✍️ ${nameInput.value} is typing` });
});
messageInput.addEventListener('blur', () => {
  socket.emit('feedback', { feedback: '' });
});

socket.on('feedback', (data) => {
  clearFeedback();
  const element = `
    <li class="message-feedback">
      <p class="feedback" id="feedback">${data.feedback}</p>
    </li>`;
  messageContainer.innerHTML += element;
});

// Add message to UI
function addMessageToUI(isOwnMessage, data) {
  clearFeedback();
  const element = `
    <li class="${isOwnMessage ? "message-right" : "message-left"}">
      <p class="message">
        ${data.message}
        <span>${data.name || data.from} ● ${moment(data.dateTime).fromNow()}</span>
      </p>
    </li>`;
  messageContainer.innerHTML += element;
  scrollToBottom();
}

// Clear feedback
function clearFeedback() {
  document.querySelectorAll('li.message-feedback').forEach(el => el.remove());
}

// Scroll to bottom
function scrollToBottom() {
  messageContainer.scrollTo(0, messageContainer.scrollHeight);
}

// Update total clients
socket.on('clients-total', (data) => {
  clientsTotal.innerText = `Total Clients: ${data}`;
});
socket.on('connect', () => {
    console.log("Your socket ID:", socket.id);
    document.body.insertAdjacentHTML('afterbegin', `<p>Your ID: ${socket.id}</p>`);
});

function sendPrivateMessage() {
    const recipientId = document.getElementById('private-recipient').value;
    const message = document.getElementById('private-message').value;

    if (recipientId && message) {
        socket.emit('private-message', {
            recipientId,
            message,
        });
    }
}

socket.on('private-message', (data) => {
    const div = document.getElementById('private-messages');
    const msg = document.createElement('p');
    msg.innerText = `Private from ${data.senderId}: ${data.message}`;
    msg.style.color = 'green';
    div.appendChild(msg);
});
