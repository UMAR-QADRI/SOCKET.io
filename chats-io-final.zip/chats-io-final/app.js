const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.redirect('/login.html');
});

const server = app.listen(PORT, () => {
    const address = `http://localhost:${PORT}/login.html`;
    console.clear();
    console.log('\x1b[36m%s\x1b[0m', '💬 Server is running!');
    console.log('\x1b[32m%s\x1b[0m', `👉 Open this link: ${address}`);
});

const io = require('socket.io')(server);

let socketsConnected = new Set();

io.on('connection', (socket) => {
    console.log(`[+] New client connected: ${socket.id}`);
    socketsConnected.add(socket.id);
    io.emit('clients-total', socketsConnected.size);

    socket.on('disconnect', () => {
        console.log(`[-] Client disconnected: ${socket.id}`);
        socketsConnected.delete(socket.id);
        io.emit('clients-total', socketsConnected.size);
    });

    socket.on('message', (data) => {
        console.log('Message received:', data);
        socket.broadcast.emit('chat-message', data);
    });

    socket.on('feedback', (data) => {
        socket.broadcast.emit('feedback', data);
    });

    // 🚀 Private messaging feature
    socket.on('private-message', ({ recipientId, message }) => {
        io.to(recipientId).emit('private-message', {
            senderId: socket.id,
            message,
        });
    });
});
